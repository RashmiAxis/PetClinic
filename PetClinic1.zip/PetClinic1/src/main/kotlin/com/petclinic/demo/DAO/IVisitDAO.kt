package com.petclinic.demo.DAO

import com.petclinic.demo.model.visit
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.stereotype.Repository

@Repository
interface IVisitDAO:MongoRepository<visit,Int> {
}