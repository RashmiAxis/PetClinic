package com.petclinic.demo.DTO

class LoginDTO {
    val email = ""
    val password = ""
}