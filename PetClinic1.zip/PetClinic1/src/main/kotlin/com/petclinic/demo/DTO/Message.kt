package com.petclinic.demo.DTO

class Message(public val message: String) {
}