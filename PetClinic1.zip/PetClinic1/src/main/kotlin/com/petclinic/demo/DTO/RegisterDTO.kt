package com.petclinic.demo.DTO

class RegisterDTO {
    val name = ""
    val email = ""
    val password = ""
}