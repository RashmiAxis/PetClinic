package com.petclinic.demo.controller

import com.petclinic.demo.model.Booking
import com.petclinic.demo.services.IBookingService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("clinicn")
class BookingController {
    @Autowired
    private lateinit var iBookingService: IBookingService
    @PostMapping("/addBooking")
    fun addBooking(@RequestBody booking: Booking): ResponseEntity<Any?> {
        val addBooking = iBookingService.addBooking(booking)
        return ResponseEntity(addBooking, HttpStatus.OK)
    }

    @GetMapping("/getAllBooking")
    fun getAllBooking(): ResponseEntity<MutableList<Booking?>>
    {
        val bookinglist = iBookingService.getAllBooking()
        return ResponseEntity(bookinglist, HttpStatus.OK)
    }
}