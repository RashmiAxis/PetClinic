package com.petclinic.demo.controller

import com.petclinic.demo.model.Owner
import com.petclinic.demo.services.ILoginService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/clinic")
class LoginController {
    @Autowired
    private lateinit var iLoginService: ILoginService

    @PostMapping("/signup")
    fun signUp(@RequestBody user: Owner): ResponseEntity<Owner?> {
        var signup =iLoginService.signUp(user)
        return ResponseEntity(signup, HttpStatus.OK)
    }
}