package com.petclinic.demo.controller

import com.petclinic.demo.DAO.IOwnerDAO
import com.petclinic.demo.feingservice.ownnerfeingservice
import com.petclinic.demo.model.Owner
import com.petclinic.demo.services.ILoginService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/clinic")
class LoginController {
    @Autowired
    private lateinit var iLoginService: ILoginService

    @Autowired
    private lateinit var  Ownerfeingservice:ownnerfeingservice

    @PostMapping("/sign")
    fun sign(@RequestBody user: Owner): ResponseEntity<Owner?> {
        var signup =iLoginService.signUp(user)
        return ResponseEntity(signup, HttpStatus.OK)
    }

    @PostMapping("/signup")
    fun signUp(@RequestBody user: Owner): ResponseEntity<ResponseEntity<Any?>>
    {
        return ResponseEntity.ok(Ownerfeingservice.signUp(user))
    }
}