package com.petclinic.demo.controller

import com.petclinic.demo.model.Pet
import com.petclinic.demo.services.IPetService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
@RestController
@RequestMapping("add")
class petController {

        @Autowired
        private lateinit var iPetService: IPetService
        @PostMapping("/addPet")
        fun addPet(@RequestBody Pet: Pet): ResponseEntity<Any?> {
            val addPet = iPetService.addPet(Pet)
            return ResponseEntity(addPet, HttpStatus.OK)
        }

        @GetMapping("/getAllPet")
        fun getAllPet(): ResponseEntity<MutableList<Pet?>>
        {
            val Petlist = iPetService.getAllPet()
            return ResponseEntity(Petlist, HttpStatus.OK)
        }
    }
