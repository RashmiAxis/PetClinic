package com.petclinic.demo.controller

import com.petclinic.demo.model.visit
import com.petclinic.demo.services.IVisitService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import java.util.*
@RestController
@RequestMapping("/visit")
class visitController {
    @Autowired
    private lateinit var iVisitService: IVisitService

    @PostMapping("/addvisit")
    fun addvisit(@RequestBody visit: visit): ResponseEntity<Any?> {
        val addvisit = iVisitService.addvisit(visit)
        return ResponseEntity(addvisit, HttpStatus.OK)
    }

    @GetMapping("/getAllVisit")
    fun getAllvisit(): ResponseEntity<MutableList<visit?>>
    {
        var visitList = iVisitService.getAllvisit()
        return ResponseEntity(visitList, HttpStatus.OK)
    }
    @GetMapping("/getvisitById/{id}")
    fun getvisitById(@PathVariable id:Int): ResponseEntity<Optional<visit?>> {
        val visitDetails = iVisitService.getvisitById(id)
        return ResponseEntity(visitDetails, HttpStatus.OK)
    }

    @Throws(Exception::class)
    @PutMapping("/updatevisitById/{id}")
    fun updatevisit(@PathVariable id: Int, @RequestBody visit: visit): ResponseEntity<Any?>
    {
        try {
            val updatevisit=   iVisitService.updatevisit(id,visit)
            return ResponseEntity(updatevisit, HttpStatus.OK)
        }
        catch (e:Exception)
        {
            return ResponseEntity("no id found", HttpStatus.NOT_FOUND)
        }

    }
    @DeleteMapping("/deleteById/{id}")
    fun deletevisitById(@PathVariable id: Int): ResponseEntity<String?>
    {
        var deletevisit = iVisitService.deletevisit(id)
        return ResponseEntity(deletevisit, HttpStatus.OK)
    }
}