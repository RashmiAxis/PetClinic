package com.petclinic.demo.feingservice

import com.petclinic.demo.DAO.IOwnerDAO

import com.petclinic.demo.model.Owner
import org.springframework.cloud.openfeign.FeignClient
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody

@FeignClient(value = "ownerclientApplication", url = "http://ownerclient-env.eba-3nvegynq.us-east-2.elasticbeanstalk.com/")
interface ownnerfeingservice {

    @PostMapping("/clinic/signup")
    fun signUp(@RequestBody user: Owner): ResponseEntity<Any?>
}