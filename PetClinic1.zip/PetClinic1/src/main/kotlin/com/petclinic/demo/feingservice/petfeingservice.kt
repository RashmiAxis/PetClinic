package com.petclinic.demo.feingservice

import com.petclinic.demo.model.Pet
import org.springframework.cloud.openfeign.FeignClient
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody

@FeignClient(value = "PetclientApplication", url = "http://localhost:8764")
interface petfeingservice {
    @PostMapping("/add/addPet")
    fun addPet(@RequestBody Pet: Pet): ResponseEntity<Any?>
}