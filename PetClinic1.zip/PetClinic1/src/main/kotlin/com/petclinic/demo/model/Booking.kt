package com.petclinic.demo.model

import com.fasterxml.jackson.annotation.JsonFormat
import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document
import org.springframework.data.mongodb.core.mapping.DocumentReference
import java.util.*

@Document(collection="booking")
class Booking(

    @Id
    var _id:Int,
    @DocumentReference
    var owner: Owner,
    @DocumentReference
    var visit:visit,
    @JsonFormat(pattern="yyyy-MM-dd")
    var bookingStartTime: Date,
    var bookingEndTime: Date
)