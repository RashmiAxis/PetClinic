package com.petclinic.demo.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document
import org.springframework.format.annotation.DateTimeFormat
import java.util.*

@Document(collection = "Pet")
open class Pet (
    var PetName:String,
    var breed:String,

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    var birthDate: Date? = null
)