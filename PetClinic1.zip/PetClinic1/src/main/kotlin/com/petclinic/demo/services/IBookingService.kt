package com.petclinic.demo.services

import com.petclinic.demo.model.Booking

interface IBookingService {
    fun addBooking(booking: Booking): Any?
    fun getAllBooking(): MutableList<Booking?>
}