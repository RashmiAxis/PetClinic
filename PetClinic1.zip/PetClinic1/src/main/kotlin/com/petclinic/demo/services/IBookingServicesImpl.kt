package com.petclinic.demo.services

import com.petclinic.demo.DAO.IBookingDAO
import com.petclinic.demo.DAO.IOwnerDAO
import com.petclinic.demo.DAO.IPetDAO
import com.petclinic.demo.DAO.IVisitDAO
import com.petclinic.demo.model.Booking
import com.petclinic.demo.model.Pet
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class IBookingServicesImpl :IBookingService{
    @Autowired
    private lateinit var iBookingDAO: IBookingDAO
    @Autowired
    private lateinit var ivisitDAO: IVisitDAO
    @Autowired
    private lateinit var iownerDAO: IOwnerDAO


    override fun addBooking(booking: Booking): Any? {
        var getvisit = ivisitDAO.findById(booking.visit!!._id).get()

        if(getvisit.availableslots<=0){
            return "No slots available"
        }
        return if(!ivisitDAO.existsById(booking.visit!!._id))
        {
            "Booking with this id not found"
        }else if(!iownerDAO.existsById(booking.owner!!._id)){
            "User with this id not found"
        }else{
            iBookingDAO.save(booking)
            //Decrease count of available slots
            var acc = ivisitDAO.findById(booking.visit!!._id).get()
            acc.availableslots = acc.availableslots -1;
            ivisitDAO.save(acc)
        }
    }

    override fun getAllBooking(): MutableList<Booking?> {
        return iBookingDAO.findAll()
    }
}