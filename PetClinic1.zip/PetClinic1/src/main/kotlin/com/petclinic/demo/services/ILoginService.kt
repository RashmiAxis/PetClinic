package com.petclinic.demo.services

import com.petclinic.demo.model.Owner

interface ILoginService {
    fun signUp(owner: Owner): Owner?
}