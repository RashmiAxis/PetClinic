package com.petclinic.demo.services

import com.petclinic.demo.DAO.IOwnerDAO
import com.petclinic.demo.model.Owner
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class ILoginServiceImpl:ILoginService{
    @Autowired
    private lateinit var iownerDAO: IOwnerDAO
    override fun signUp(owner: Owner): Owner? {
        return iownerDAO.save(owner)
    }
}