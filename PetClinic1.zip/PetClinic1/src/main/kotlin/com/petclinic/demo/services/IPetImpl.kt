package com.petclinic.demo.services

import com.petclinic.demo.DAO.IBookingDAO
import com.petclinic.demo.DAO.IPetDAO

import com.petclinic.demo.model.Pet
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class IPetImpl :IPetService{

    @Autowired
    private lateinit var iPetDAO: IPetDAO
    @Autowired
    private lateinit var iBookingDAO: IBookingDAO

    override fun addPet(Pet: Pet): Any? {
          return  iPetDAO.save(Pet)
        }

    override fun getAllPet(): MutableList<Pet?> {
    return iPetDAO.findAll()
}
}
