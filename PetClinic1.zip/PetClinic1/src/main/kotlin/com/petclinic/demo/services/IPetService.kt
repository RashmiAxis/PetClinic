package com.petclinic.demo.services

import com.petclinic.demo.model.Pet

interface IPetService {
    fun addPet(Pet: Pet): Any?
    fun getAllPet(): MutableList<Pet?>
}