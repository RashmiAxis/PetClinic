package com.petclinic.demo.services

import com.petclinic.demo.model.visit
import java.util.*

interface IVisitService {
    fun addvisit(visit: visit):Any?
    fun getAllvisit(): MutableList<visit?>
    fun getvisitById(Id: Int): Optional<visit?>
    fun updatevisit(id:Int,Petclinic: visit):Any?
    fun deletevisit(id:Int):String

}