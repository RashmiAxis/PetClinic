package com.petclinic.demo.services

import com.petclinic.demo.DAO.IVisitDAO
import com.petclinic.demo.model.visit
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*
import kotlin.jvm.Throws

@Service
class IVisitServiceImpl:IVisitService {
    @Autowired
    private lateinit var ivisitDAO: IVisitDAO

    override fun addvisit(visit: visit): Any?
    {
        // return if(ivisitDAO.existsById(visit.owner!!._id))
        //{
        return  ivisitDAO.save(visit)
        //}else {
        // "owner with id not found"
        // }
    }

    override fun getAllvisit(): MutableList<visit?> {
        return ivisitDAO.findAll()
    }

    override fun getvisitById(Id: Int): Optional<visit?> {
        return ivisitDAO.findById(Id)
    }

    @Throws(Exception::class)
    override fun updatevisit(id: Int, visit: visit): Any? {

        return if(ivisitDAO.existsById(id)){
            var acc = ivisitDAO.findById(id).get()
            acc.name =  visit.name
            acc.address = visit.address
            acc.country = visit.country
            acc.city = visit.city
            acc.state = visit.state
            acc.price = visit.price
            acc.totalslots = visit.totalslots
            acc.availableslots = visit.availableslots
//            iParkingDAO.save(acc)
            return if(ivisitDAO.existsById(visit.owner!!._id))
            {
                ivisitDAO.save(visit)
            }else {
                "owner with id not found"
            }
        } else
        {
            throw Exception("visit id not found")
        }
    }

    override fun deletevisit(id: Int): String {
        return if(ivisitDAO.existsById(id))
        {
            ivisitDAO.deleteById(id)
            "Visit id deleted"
        }
        else {
            "visit with id $id not found"
        }
    }

}