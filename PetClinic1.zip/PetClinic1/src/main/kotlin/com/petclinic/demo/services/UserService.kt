package com.petclinic.demo.services

import com.petclinic.demo.DAO.UserRepository
import com.petclinic.demo.model.User

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class UserService {
    @Autowired
    private val userRepository: UserRepository?=null

    fun save(user: User): User {
        return this.userRepository!!.save(user)
    }

    fun findByEmail(email: String): User? {
        return this.userRepository!!.findByEmail(email)
    }

    fun getById(id: Int): Any {
        return this.userRepository!!.findById(id)
    }
}