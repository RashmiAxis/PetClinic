package com.petclinic.demo

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class PetclinicApplicationTests {

	@Test
	fun contextLoads() {
	}

}
