package com.feign.demo.controller


import com.feign.demo.service.feignClientImpl
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("getData")
class feignClientController {
    @Autowired
    private lateinit var clientServiceImpl: feignClientImpl

    @GetMapping("feign")
    fun get(): ResponseEntity<Any> {
        return ResponseEntity(clientServiceImpl.getUsers(), HttpStatus.OK)
    }
}