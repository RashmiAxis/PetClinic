package com.feign.demo.service

import com.feign.demo.client.feignClient
import org.springframework.beans.factory.annotation.Autowired

import org.springframework.stereotype.Service

@Service
class feignClientImpl {
    @Autowired
    private lateinit var feignClient: feignClient

    fun getUsers():Any{
        return feignClient.getAllUsers()
    }
}