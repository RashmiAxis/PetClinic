package com.feign.demo

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class FeignApplicationTests {

	@Test
	fun contextLoads() {
	}

}
