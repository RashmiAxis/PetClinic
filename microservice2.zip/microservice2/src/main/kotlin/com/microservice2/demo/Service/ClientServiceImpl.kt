package com.microservice2.demo.Service

import com.microservice2.demo.client.FeignClient
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class ClientServiceImpl {
    @Autowired
    private lateinit var feignClient: FeignClient

    fun getUsers():Any{
        return feignClient.getAllUsers()
    }
}