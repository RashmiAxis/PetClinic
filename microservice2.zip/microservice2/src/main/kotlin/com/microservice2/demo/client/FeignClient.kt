package com.microservice2.demo.client

import org.springframework.web.bind.annotation.GetMapping
import org.springframework.cloud.netflix.feign.FeignClient

@FeignClient("http://localhost:8762/userAccount")
interface FeignClient {
    @GetMapping("/getAll")
    fun getAllUsers():List<Any>
}