package com.microservice2.demo.controller

import com.microservice2.demo.Service.ClientServiceImpl
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("getData")
class FeignClientController {
    @Autowired
    private lateinit var clientServiceImpl: ClientServiceImpl

    @GetMapping("feign")
    fun get(): ResponseEntity<Any> {
        return ResponseEntity(clientServiceImpl.getUsers(), HttpStatus.OK)
    }
}