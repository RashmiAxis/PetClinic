package com.owner.demo.DAO

import com.owner.demo.model.Owner
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.stereotype.Repository

@Repository
interface IOwnerDAO: MongoRepository<Owner, Int> {
}