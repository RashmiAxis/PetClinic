package com.owner.demo.controller

import com.owner.demo.model.Owner
import com.owner.demo.service.ILoginService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/clinic")
class ILoginController {
    @Autowired
    private lateinit var iLoginService: ILoginService

    @PostMapping("/signup")
    fun signUp(@RequestBody user: Owner): ResponseEntity<Owner?> {
        var signup =iLoginService.signUp(user)
        return ResponseEntity(signup, HttpStatus.OK)
    }
}