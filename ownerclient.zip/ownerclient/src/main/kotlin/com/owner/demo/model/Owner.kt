package com.owner.demo.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document

@Document(collection = "owner")
data class Owner(
    @Id
    var _id:Int,
    var name:String,
    var mobileNo:String,
    var email:String,
    var password:String,
)