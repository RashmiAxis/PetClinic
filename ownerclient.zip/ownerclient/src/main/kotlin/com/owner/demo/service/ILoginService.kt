package com.owner.demo.service

import com.owner.demo.model.Owner

interface ILoginService {
    fun signUp(owner: Owner): Owner?
}