package com.owner.demo.service

import com.owner.demo.DAO.IOwnerDAO
import com.owner.demo.model.Owner
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class ILoginServiceImpl:ILoginService{
    @Autowired
    private lateinit var iownerDAO: IOwnerDAO
    override fun signUp(owner: Owner): Owner? {
        return iownerDAO.save(owner)
    }
}