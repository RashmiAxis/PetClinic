package com.petclient.demo.DAO

import com.petclient.demo.model.Pet
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.stereotype.Repository


@Repository
interface IPetDAO : MongoRepository<Pet, String> {
}