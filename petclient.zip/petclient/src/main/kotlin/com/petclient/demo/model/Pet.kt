package com.petclient.demo.model

import org.springframework.data.mongodb.core.mapping.Document
import org.springframework.format.annotation.DateTimeFormat
import java.util.*


@Document(collection = "pet")
open class Pet (

    var petName:String,
    var breed:String,

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    var birthDate: Date? = null
)