package com.petclient.demo.service

import com.petclient.demo.DAO.IPetDAO
import com.petclient.demo.model.Pet
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service


@Service
class IPetImpl :IPetService{

    @Autowired
    private lateinit var iPetDAO: IPetDAO

    override fun addPet(Pet: Pet): Any? {
        return  iPetDAO.save(Pet)
    }

    override fun getAllPet(): MutableList<Pet?> {
        return iPetDAO.findAll()
    }
}