package com.petclient.demo.service

import com.petclient.demo.model.Pet


interface IPetService {
    fun addPet(Pet: Pet): Any?
    fun getAllPet(): MutableList<Pet?>
}