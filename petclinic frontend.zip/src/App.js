import Header from './components/Header';
import './App.css';
import Home from './components/Home';
import 'react-accessible-accordion/dist/fancy-example.css';
import { ToastContainer, toast } from 'react-toastify';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Navbar ,Container,Nav,NavDropdown,FormControl,Form,NavLink} from 'react-bootstrap';
import AddOwner from './components/AddOwner';
import { Col, Row } from 'reactstrap';
import Menu from './components/Menu';
import { BrowserRouter as Router,Route,Link,Switch} from "react-router-dom";
import About from './components/About';
import Contact from './components/Contact';

import ViewAllBooking from './Booking/ViewAllBooking';
import Login from './components/Login';
import Register from './components/Register';
import { useState } from 'react';
import Addvisit from './visit/AllVisit';
import Booking from './Booking/Booking';
import AddPet from './pet/Addpet';
import visit from './components/visit';
import AllVisit from './components/AllVisits';
import visitingdetails from './components/visitingdetail';
import AllPet from './pet/Allpet';
import pet from './pet/pet';






function App() {
 
  const btnHandle=()=>
  {toast.success("Sucess")}
  

  return ( 
    
 
   

   <div className='body'> 

     
     <Router> 
     <ToastContainer/>
    
       <Header/>
        <Container>
       <Row>
         <Col md={4}>
           <Menu/>
         </Col>
         <Col md={8}>
           <Route path="/" component={Home} exact/>
           <Route path="/aboutUs" component={About} exact/>
           <Route path="/add-Owner" component={AddOwner} exact/>
           
           <Route path="/addpet" component={AddPet} exact/>
           <Route path="/view-pet" component={pet} exact/>
           <Route path="/view-visitdetails" component={visitingdetails} exact/>
           <Route path="/ContactUs" component={Contact} exact/>
           <Route path="/visit-addvisit" component={visit} exact/>
           <Route path="/home-login" component={Login} exact/>
           <Route path="/home-register" component={Register} exact/>
           <Route path="/AllBookings" component={ViewAllBooking} exact/>
         </Col>
       </Row>
       
     </Container>
     </Router>
  </div>
   
  );
}

export default App;
