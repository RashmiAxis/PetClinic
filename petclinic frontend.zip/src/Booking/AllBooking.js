
import React,{useEffect,useState} from "react";
import { Card,CardBody,CardTitle,CardSutitle,CardText,CardFooter,Button,Container, CardSubtitle } from "reactstrap";
import { Link } from "react-router-dom";

import Owner from "../components/Owner";
import axios from "axios";
import base_url from "../api/bootapi";
import { ToastContainer, toast } from 'react-toastify';
import Booking from "./Booking";

const Booking=()=> {
    useEffect(()=>{
        document.title="All Bookings || Welcome to pet clinic";
    },[]);

  

  const[booking,setbooking]=useState([{}]);

  const addnewBookingtoserver=()=>{
    axios.get(`${base_url}/bookings`).then(
        (response)=>{
            //for success
            console.log(response.data);
            toast.success("Sucessfully Added");
            setbooking(response.data);
        },
        (error)=>{
            //for error
            console.log(error);
            toast.error("Error");
        }
    )
    }
    //calling loading booking function
//npx json-server --watch Addowner.json
useEffect(()=>{
    addnewBookingtoserver();},[])

    return(
        <div> 
            <h1 className="text-center">All Booking</h1>
            {booking.length > 0
            //? owner.map((item)=><Owner  owner={item}/>)
            ? booking.map((item)=><Pet key={item.id} booking={item}/>)
            : "No booking Details"}
           
        </div>
        
        );
          
    }
    export default Booking;
        