import React,{Fragment,useState,useEffect} from "react";

import axios from "axios";
import { Button, Container, Form,FormGroup,Input ,Label} from "reactstrap";
import base_url from "../api/bootapi";
import { ToastContainer, toast } from 'react-toastify';
//import useState from 'react-hook-use-state';

const booking=()=>{

  useEffect(()=>{
    document.title="Add Booking || Welcome to Pet Clinic"
    },[]);

  const[booking,setbooking]=useState({});


    //  Form_Input_Handler
    const handleForm = (e) => {
      e.preventDefault();
      const {bookingStartTime, value} = e.target
      setbooking((oldValue)=>{return {...oldValue, [bookingStartTime]:value }})
    };
    
    //creating function to post data on server
    const postBookingService = () => {      
      console.log(visit);
      axios.post(`${base_url}/clinicn/addBooking`,visit)
      .then((response)=>{
          console.log(response);
          console.log("success");
          toast.success("Booking Details Added");
       },
       (error)=>{
         console.log(error);
         console.log("error");
               toast.error("Error");
           }
      );
    };
    return(
        
         <div>
             <h1 className="text-center">Visiting Details</h1>
             <Form onSubmit={postBookingService} >
          
              <hr></hr>
              <div class="form">
                <div class="form-group col-md-6">
                  <label for="input_id">Booking_Id</label>
                  <input type="number" name="_id" class="form-control" id="inputvid" value={booking._id} onChange={handleForm} placeholder="Booking_Id"></input>
                </div>
                <div class="form-group col-md-6">
                  <label for="inputbookingStartTime">Booking Start Date</label>
                  <input type="text" name="bookingStarTime" class="form-control" id="inputbookingStartTime" value={booking.bookingStartTime} onChange={handleForm} placeholder="Booking Start Date"></input>
                </div>
                
              <div class="form-group">
                <label for="inputbookingEndTime">Booking End Date</label>
                <input type="text" name="bookingEndTime" class="form-control" id="bookingEndTime" value={booking.bookingEndTime} onChange={handleForm} ></input>
              </div>
              
            
                
              </div><hr></hr>
            <Button type="submit" color="success">Add</Button>

          </Form>
  </div>
        
    )
}
export default booking;