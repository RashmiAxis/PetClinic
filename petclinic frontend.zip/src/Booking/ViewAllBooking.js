
import React,{useEffect,useState} from "react";
import { Card,CardBody,CardTitle,CardSutitle,CardText,CardFooter,Button,Container, CardSubtitle } from "reactstrap";
import { Link } from "react-router-dom";

import Owner from "../components/Owner";
import axios from "axios";
import base_url from "../api/bootapi";
import { ToastContainer, toast } from 'react-toastify';

export default function ViewAllBooking () {
    useEffect(()=>{
        document.title="All Bookings || Welcome to pet clinic";
    },[]);
    const[booking,setbooking]=useState([]);

  const addBookingtoserver=()=>{
    axios.get(`http://newpetclinicservices-env.eba-vkgx5txv.us-east-2.elasticbeanstalk.com/clinicn/getAllBooking`).then(
        (response)=>{
            //for success
            console.log(response.data);
            toast.success("Sucessfully Added");
            setbooking(()=>response.data);
           
           
        },
        (error)=>{
            //for error
            console.log(error);
            toast.error("Error");
        }
    )
    }
    console.log(booking);
    //calling loading booking function
//npx json-server --watch Addowner.json
useEffect(()=>{
    addBookingtoserver();},[])

    return(
        <div>
            
            <h1 className="text-center">Booking Details</h1>
      {booking.map(item =>{
          return(

              <>
              <Card>
            <CardBody>
            <table className="table table-bordered text-center table-striped">
                    <tbody>
                    <tr><th width="30%">Booking Id</th><td width="2%">:</td><td>{item._id}</td></tr>
                    {/* <tr><th width="30%">Owner Id</th><td width="2%">:</td><td>{item.owner}</td></tr> */}
                     {/* <tr><th width="30%">Owner Id</th><td width="2%">:</td><td>{item.Owner.id}</td></tr>
                    <tr><th width="30%">Owner Name</th><td width="2%">:</td><td>{item.Owner.name}</td></tr>
                    <tr><th width="30%">Phone Number</th><td width="2%">:</td><td>{item.Owner.number}</td></tr>
                    <tr><th width="30%">Email</th><td width="2%">:</td><td>{item.Owner.email}</td></tr> */}
                    <tr><th width="30%">Visiting Id</th><td className="text-center" width="2%">:</td><td>{item.visit}</td></tr>
                    {/* <tr><th width="30%">Clinic Name	</th><td width="2%">:</td><td>{item.visit.name}</td></tr>
                    <tr><th width="30%">Address	</th><td width="2%">:</td><td>{item.visit.address}</td></tr>
                    <tr><th width="30%">Country</th><td width="2%">:</td><td>{item.visit.country}</td></tr>
                    <tr><th width="30%">State</th><td width="2%">:</td><td>{item.visit.state}</td></tr>
                    <tr><th width="30%">City</th><td width="2%">:</td><td>{item.visit.city}</td></tr>
                    <tr><th width="30%">Price</th><td width="2%">:</td><td>{item.visit.price}</td></tr>
                    <tr><th width="30%">Total Slots</th><td width="2%">:</td><td>{item.visit.totalslots}</td></tr>
                    <tr><th width="30%">Available Slots</th><td width="2%">:</td><td>{item.visit.availableslots}</td></tr> */}
                    <tr><th width="30%">Booking Start</th><td width="2%">:</td><td>{item.bookingStartTime}</td></tr>
                    <tr><th width="30%">Booking End	</th><td width="2%">:</td><td>{item.bookingEndTime}</td></tr>
                    </tbody>
                 </table>
                

            </CardBody>
            </Card>
            </>
           )
        })}
        </div>
        
        )
          
    }
        