const base_url="http://newpetclinicservices-env.eba-vkgx5txv.us-east-2.elasticbeanstalk.com"
export default base_url;
