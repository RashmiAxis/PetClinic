import React,{useState} from "react";
import Login from "./components/Login";
import { Button, Navbar ,Container,Nav,NavDropdown,FormControl,Form,NavLink,Redirect} from 'react-bootstrap';
import { BrowserRouter as Router,Route,Link,Switch, Redirect} from "react-router-dom";
import Authapi from "./authapi";
import Cookies from "js-cookie";
import { Cookie } from "express-session";

const Sample =()=>{

    //main
    const [auth,setauth]=React.useState(false)
    const readCookie=()=>{
        const user=Cookies.get("user")
        if(user){
            setauth(true);
        }
    }
    React.useEffect(()=>{
        readCookie();},[])
    

    const login=()=>{
    const Auth= React.createContext(AuthApi)
    const handleonClick=()=>{
        Auth.setauth(true);
        Cookies.set("user","loginTrue")
    }
    //login.js page
    //in app.js before<Route/> <AuthApi.provider value={(auth,setauth)}></AuthApi.Provider>
  { return(
    <div> <h1>Welcome</h1>
    <Button onClick={handleonClick}>Login</Button></div>)
  }}
  const Dashboard=()=>{
  const Auth= React.createContext(AuthApi)
  const handleOnClick=()=>{
      Auth.setauth(false);
      Cookie.remove("user");
  }
  //home.js
  { return(
    <div><h1>Dashboard</h1>
    <Button onClick={handleOnClick}>Logout</Button></div>)
  }
  const Route=()=>{
  const Auth= React.createContext(AuthApi)
  { return(<div>
   <Switch>
     <Route path="/login" auth={auth.Auth} component={Login} exact/>
    <Route path="/dashboard" auth={auth.Auth} component={Dashboard} exact/>
 </Switch></div>)
  }
}
  }
  const Protectedroute=({auth,component:Component,...rest})=>{
   return(
   <Route
   {...rest} 
   render={()=>(
    <Component/>
    ):
(
<Redirect to="/login"/>
)
}
    />
   )
}
const Protectedlogin=({auth,component:Component,...rest})=>{
    return(
    <Route
    {...rest} 
    render={()=>{
     (<Component/>)
    ?
 (
 <Redirect to="/dashboard"/>
 )
    
     
    )}}
 

export default Sample;