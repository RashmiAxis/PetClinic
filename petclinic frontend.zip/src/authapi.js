import React from "react";
const Authapi=React.createContext();
export default Authapi;