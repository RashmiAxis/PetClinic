import React,{useEffect} from 'react';

const About=()=>{
    useEffect(()=>{
        document.title="About Us || Welcome to Pet Clinic"
    },[])
    return(
        <div >
             <div class="jumbotron" style={{backgroundColor:"pink" , marginTop:"20px", borderRadius:"15px"}}>
            <h1 className='text-center'style={{textDecoration:"underline" }}>Why Pet Clinic are important?</h1>
            <p style={{textAlign:"justify",marginBottom:"20px"}}>Pet owners know that their pets are a part of the family. So, it only makes sense that as a pet owner you would want to take care of them in the exact same way that you would take are a human family member. And, just like people do, pets need to have regular check-ups with their doctor aka regular and proper veterinary care. By making regular visits to the vet, many problems can be caught early and therefore taken care of before they turn into bigger, more serious issues. Monitoring your pet’s health also is important in order to make sure he or she is as strong and as healthy as possible. Here are some of the crucial services your pet can attain through regular care.</p>
        </div>
        </div>
    )
}
export default About;