import axios from "axios";
import React,{Fragment, useEffect,useState} from "react";
import { Button, Container, Form,FormGroup,Input ,Label} from "reactstrap";
import base_url from "../api/bootapi";
import { ToastContainer, toast } from 'react-toastify';


const AddOwner=()=>{
  useEffect(()=>{
    document.title="Add Owners || Welcome to Pet Clinic"
},[]);
const[owner,setOwner]=useState([])

//form handler function
const handleForm=(e)=>{
  postDatatoserver(owner);
  e.preventDefault();
  console.log(owner);
};

//creating function to post data on server
const postDatatoserver=(data)=>{
  axios.post(`http://newpetclinicservices-env.eba-vkgx5txv.us-east-2.elasticbeanstalk.com/clinic/signup`,data).then(//error: 404 http://localhost:3000/add-Owner
   
    (response)=>{
      console.log(response);
      console.log("success");
            toast.success("Sucessfully Added");
    },
    (error)=>{
      console.log(error);
      console.log("error");
            toast.error("Error");

    }
  );
};

    return(
        
           <Fragment>
            <h1 className="text-center my-3">Fill Owner details</h1>
           <Form onSubmit={handleForm}>
  <div class="form-group">
    <label for="exampleInputid">Adhaar Card</label>
    <Input type="number" name="_id" class="form-control" id="exampleInputid" onChange={(e)=>{setOwner({...owner,_id:e.target.value});}} aria-describedby="idHelp" placeholder="Enter adhaar card number"/>
  </div>
            <div class="form-group">
    <label for="exampleInputname">Name</label>
    <Input type="text" name="name" class="form-control" id="exampleInputname" onChange={(e)=>{setOwner({...owner,name:e.target.value});}}aria-describedby="nameHelp" placeholder="Enter your name"/>
    <FormGroup>
    <Label for="exampleNumber">
      Mobile Number
    </Label>
    <Input
      type="number" name="mobileNo"
      onChange={(e)=>{setOwner({...owner,mobileNo:e.target.value});}}
     
      placeholder="Enter your mobile number"
      
    />
  </FormGroup>
  </div>
  <div class="form-group">
    <label for="exampleInputemail">Email address</label>
    <Input type="email" name="email" class="form-control" email="exampleInputemail" onChange={(e)=>{setOwner({...owner,email:e.target.value});}}aria-describedby="emailHelp" placeholder="Enter email"/>
    
  </div>
  <div class="form-group">
    <label for="exampleInputpassword">Password</label>
    <Input type="password" name="password" class="form-control" password="exampleInputpassword" onChange={(e)=>{setOwner({...owner,password:e.target.value});}} placeholder="Password"/>
    
  </div><br></br>
  <Container className="text-center">
    <Button type="submit" color="success">Add Owner</Button>
    <Button color="warning ml-4" style={{marginLeft:"15px"}}>Reset</Button>
</Container>

</Form>
</Fragment>

        
    )
}
export default AddOwner;