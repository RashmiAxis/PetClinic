import React, { useState,useEffect} from "react";
import AddOwner from "./AddOwner";
import Owner from "./Owner";
import axios from "axios";
import base_url from "../api/bootapi";
import { ToastContainer, toast } from 'react-toastify';
import { Card,CardBody,CardTitle,CardSutitle,CardText,CardFooter,Button,Container, CardSubtitle } from "reactstrap";
import { BrowserRouter as Router,Route,Link,Switch} from "react-router-dom";



export default function AllOwners () {
    useEffect(()=>{
        document.title="All Owner || Welcome to pet clinic";
    },[]);
 
  const[Owner,setOwner]=useState([{}]);

  const addOwnertoserver=()=>{
    axios.get(`${base_url}/owner`).then(
        (response)=>{
            //for success
            console.log(response.data);
            toast.success("Sucessfully Added");
            setOwner(response.data);
        },
        (error)=>{
            //for error
            console.log(error);
            toast.error("Error");
        }
    )
    }
    //calling loading booking function
//npx json-server --watch Addowner.json
useEffect(()=>{
    addOwnertoserver();},[])

    return(
        <div>
            <Card className="text-center">
            <h1>All Owners</h1>
      {Owner.map(item =>{
          return(

              <>
              <Card>
            <CardBody>
            <CardText className="font-weight-bold" >Owner Id:{item.id}</CardText>
                <CardText >Owner Name:{item.name}</CardText>
                <CardText >Phone Number:{item.number}</CardText>
                <CardText  >Email:{item.email}</CardText>
            </CardBody>
            </Card>
            </>
           )
        })}</Card>
        </div>
        
        )
           
    } 
   
   
    

   


