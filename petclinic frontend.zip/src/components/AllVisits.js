import React, { useState,useEffect} from "react";
import AddOwner from "./AddOwner";
import Owner from "./Owner";
import Visit from "./visit";
import visitingdetails from "./visitingdetail";


const AllVisits=()=>{
    useEffect(()=>{
        document.title="All Visits || Welcome to pet clinic";
    },[]);

const[visit,setVisit]=useState([{id:4,name:"",number:"123",email:"ve@1",password:"123",id:65,name:"rashmi",Address:"7644", country:"c", state:"d" ,City:"r",price:"1", totalslots:"433", availableslots:"2" ,"Owner":{"id":3}}]);

    //function to call server
   const addOwnertoserver=()=>{
    axios.get(`${base_url}/visit`).then(
        (response)=>{
            //for success
            console.log(response.data);
            toast.success("Sucessfully Added");
            setVisit(response.data);
        },
        (error)=>{
            //for error
            console.log(error);
            toast.error("Error");
        }
    )
}

//calling loading booking function
//npx json-server --watch Addowner.json
useEffect(()=>{
addOwnertoserver();},[])

    

    return(
        <div>
            <h1 className="text-center">All Visits</h1>
            
            {visit.length>0
            // visit.map((item)=><Visit  visit={item}/>)
            ? visit.map((item)=><visitingdetails key={item.id} visit={item}/>)
           //use this syntax when connect to api
            :"No Details"}
           
        </div>
    )
}
export default AllVisits;
