import React, { useState,useEffect} from "react";

const Allsignin=()=>{
    useEffect(()=>{
        document.title="All Login details || Welcome to pet clinic";
    },[]);
const[signin,setSignIn]=useState([]);
    //function to call login detail server
   const postLogindetailstoserver=()=>{
    axios.post(`${base_url}/signin`).then(
        (response)=>{
            //for success
            console.log(response.data);
            toast.success("Sucessfully Login!!");
            setSignIn(response.data);
        },
        (error)=>{
            //for error
            console.log(error);
            toast.error("Error");
        }
    )
    
//calling loading booking function
//npx json-server --watch Addowner.json
useEffect(()=>{
    postLogindetailstoserver();},[])
}

return(
<div>
    {signin.length>0
        ? signin.map((item)=><Credential key={item.name} signin={item}/>)
       // ? owner.map((item)=><Owner key={item.id} owner={item}/>)//use this syntax when connect to api
        :"No Details"}  
    </div>
)}
export default Allsignin;