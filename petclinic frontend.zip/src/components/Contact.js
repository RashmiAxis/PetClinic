import React,{useEffect} from "react";

const Contact=()=>{
    useEffect(()=>{
        document.title="Contact Us"
    },[])
    return(
        <div className="jumbotron-fluid" style={{backgroundColor:"lightgreen", height:"30%" ,width:"80%"  , marginTop:"20px", borderRadius:"15px"}}><br></br>
           <h3>Phone number</h3>
           <p>+91-7578656467</p>
           <p>+91-4466490094</p>
           <p>+91-4466490094</p>
           <h3>Email Us</h3>
           <p>petclinic21@.gmail.com</p>
        </div>
    )
}
export default Contact;