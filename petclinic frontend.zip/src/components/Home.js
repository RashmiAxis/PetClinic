import React,{useEffect} from "react";
import {Button, Container, Jumbotron} from 'reactstrap';
import { BrowserRouter as Router,Route,Link,Switch} from "react-router-dom";
import { ListGroup, ListGroupItem } from "reactstrap";

const Home=()=>{
    useEffect(()=>{
        document.title="Home || Welcome to Pet Clinic"
    },[])
    return(
        <div class="jumbotron" style={{backgroundColor:"lightgray", marginTop:"20px", borderRadius:"15px"}}>
  <h1>Welcome to Pet Clinic Application</h1>
  <p >PetClinic demonstrates the use of a Spring Boot with Spring MVC and Spring Data. The PetClinic has an old</p>
  <hr/>
 <Container>
     <br></br>
     <br></br>
     
 <Link tag="a" to="/home-login" action><Button color="success"  outline>Login</Button></Link>
 <Link tag="a" to="/home-register" action><Button color="danger" style={{marginLeft:"15px"}} outline>Register</Button></Link>
 </Container>
</div>
    )
}
export default Home;
