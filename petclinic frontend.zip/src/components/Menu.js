import React from "react";
import { ListGroup, ListGroupItem } from "reactstrap";
import { BrowserRouter as Router,Route,Link,Switch} from "react-router-dom";

const Menu=()=>{
    return(
        <ListGroup className="menu mt-3"style={{borderRadius:"10px",backgroundColor:"transparent"}}  >
  <Link style={{backgroundColor:"lightgray"}} tag="a"  to="/" className="list-group-item" action>Home</Link>
  <Link style={{backgroundColor:"lightgray"}}tag="a"  to="/aboutUs" className="list-group-item" action>About us</Link>
  <Link style={{backgroundColor:"lightgray"}}tag="a"  to="/add-Owner"  className="list-group-item" action>Register Owner</Link>
 
  <Link style={{backgroundColor:"lightgray"}}tag="a"  to="/addpet" className="list-group-item" action>Add Pet</Link>
  <Link style={{backgroundColor:"lightgray"}}tag="a"  to="/view-pet" className="list-group-item" action>View Pet</Link>
  <Link style={{backgroundColor:"lightgray"}}tag="a" to="/visit-addvisit" className="list-group-item" action>Visits</Link>
  <Link style={{backgroundColor:"lightgray"}}tag="a" to="/view-visitdetails" className="list-group-item" action>View Visit</Link>
  
  <Link style={{backgroundColor:"lightgray"}}tag="a" to="/AllBookings" className="list-group-item" action>View Booking</Link>
  
  
  <ListGroupItem style={{backgroundColor:"lightgray"}}tag="a" href="/ContactUs" action>Contact us</ListGroupItem>
</ListGroup>
    )
}
export default Menu;