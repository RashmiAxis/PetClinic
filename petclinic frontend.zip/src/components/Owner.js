import React  from "react";
import { Card,CardBody,CardTitle,CardSutitle,CardText,CardFooter,Button,Container, CardSubtitle } from "reactstrap";
import { BrowserRouter as Router,Route,Link,Switch} from "react-router-dom";
const Owner=({Owner})=>{
  
    return(
        <div>
            <Card className="text-center">
            
            <CardBody>
            
                <CardText className="font-weight-bold">{Owner.id}</CardText>
                <CardText>{Owner.name}</CardText>
                
                <Container className="text-center">
                <Button color="danger" outline>Add </Button>
               
                    <Button color="warning">Reset</Button>
                </Container>
            </CardBody>
          </Card>
        </div>
        )
    }
        export default Owner;