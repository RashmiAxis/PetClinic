import React,{Fragment,useState,useEffect} from "react";

import axios from "axios";
import { Button, Container, Form,FormGroup,Input ,Label} from "reactstrap";
import base_url from "../api/bootapi";
import { ToastContainer, toast } from 'react-toastify';
//import useState from 'react-hook-use-state';

const visit=()=>{

  useEffect(()=>{
    document.title="Add Visit || Welcome to Pet Clinic"
    },[]);

  const[visit,setVisit]=useState({_id:0,name:"",address:"",country:"",state:"",city:"",price:"",totalslots:"",availableslots:""});


    //  Form_Input_Handler
    const handleForm = (e) => {
      e.preventDefault();
      const {name, value} = e.target
      setVisit((oldValue)=>{return {...oldValue, [name]:value }})
    };
    
    //creating function to post data on server
    const postVisitServer = () => {      
      console.log(visit);
      axios.post(`${base_url}/visit/addvisit`,visit)
      .then((response)=>{
          console.log(response);
          console.log("success");
          toast.success("Visiting Details Added");
       },
       (error)=>{
         console.log(error);
         console.log("error");
               toast.error("Error");
           }
      );
    };
    return(
        
         <div>
             <h1 className="text-center">Visiting Details</h1>
             <Form onSubmit={postVisitServer} >
          
              <hr></hr>
              <div class="form">
                <div class="form-group col-md-6">
                  <label for="input_id">Visiting_Id</label>
                  <input type="number" name="_id" class="form-control" id="inputvid" value={visit._id} onChange={handleForm} placeholder="Visiting_Id"></input>
                </div>
                <div class="form-group col-md-6">
                  <label for="inputcname">Clinic Name</label>
                  <input type="text" name="name" class="form-control" id="inputcname" value={visit.name} onChange={handleForm} placeholder="Clinic Name"></input>
                </div>
                
              <div class="form-group">
                <label for="inputAddress">Address</label>
                <input type="text" name="address" class="form-control" id="inputaddress" value={visit.address} onChange={handleForm} ></input>
              </div>
              <div class="form-group">
              <div class="form-group col-md-6">
                <label for="inputcountry">Country</label>
                <input type="text" name="country" class="form-control" id="inputcountry" value={visit.country} onChange={handleForm} ></input>
              </div></div>
              <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="inputstate">State</label>
                    <input type="text" name="state" class="form-control" id="inputstate" value={visit.state} onChange={handleForm} ></input>
                  </div>
                  <div class="form-row">
                    <div class="form-group col-md-6">
                      <label for="inputCity">City</label>
                      <input type="text" name="city" class="form-control" id="inputcity" value={visit.city} onChange={handleForm}></input>
                    </div>

                    <div class="form-group col-md-2">
                      <label for="inputZip">Visit Charges</label>
                      <input type="text" name="price" class="form-control" id="inputprice" value={visit.price} onChange={handleForm} ></input>
                    </div>
                  </div>
                
                  <div class="form-group col-md-2">
                    <label for="inputtotalslots">Total Slots</label>
                    <input type="text" name="totalslots" class="form-control" id="inputtotalslots" value={visit.totalslots} onChange={handleForm}></input>
                  </div>
              </div>
  
                <div class="form-group col-md-2">
                  <label for="inputavailableslots">Available Slots </label>
                  <input type="text" name="availableslots" class="form-control" id="inputavailableslots" value={visit.availableslots} onChange={handleForm} ></input>
                </div>
              </div><hr></hr>
            <Button type="submit" color="success">Add</Button>

          </Form>
  </div>
        
    )
}
export default visit;