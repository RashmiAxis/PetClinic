
import React,{useEffect,useState} from "react";
import { Card,CardBody,CardTitle,CardSutitle,CardText,CardFooter,Button,Container, CardSubtitle } from "reactstrap";
import { Link } from "react-router-dom";
import AllOwners from "./AllOwners";
import axios from "axios";
import base_url from "../api/bootapi";
import { ToastContainer, toast } from 'react-toastify';
import './visitingdetail.css';

export default function visitingdetails () {
    useEffect(()=>{
        document.title="All Visit || Welcome to pet clinic";
    },[]);
    const[visit,setVisit]=useState([]);

  

  const addvisittoserver=()=>{
    axios.get(`${base_url}/visit/getAllVisit`).then(
        (response)=>{
            //for success
            console.log(response.data);
            toast.success("Sucessfully Added");
            setVisit(()=>response.data);
            
        },
        (error)=>{
            //for error
            console.log(error);
            toast.error("Error");
        }
    ) 
   
    }
    console.log(visit);
    //calling loading booking function
//npx json-server --watch Addowner.json
useEffect(()=>{
    addvisittoserver();},[])

    return(
        <div>
            
            <h1 className="text-center">Visiting Details</h1>
      {visit.map((item) =>{
          return(

              <>
              <Card>
            <CardBody>
        
                 <table className="table table-bordered text-center table-striped">
                    <tbody>
                    <tr><th width="30%">Visiting Id</th><td className="text-center" width="2%">:</td><td>{item._id}</td></tr>
                    <tr><th width="30%">Clinic Name	</th><td width="2%">:</td><td>{item.name}</td></tr>
                    <tr><th width="30%">Address	</th><td width="2%">:</td><td>{item.address}</td></tr>
                    <tr><th width="30%">Country</th><td width="2%">:</td><td>{item.country}</td></tr>
                    <tr><th width="30%">State</th><td width="2%">:</td><td>{item.state}</td></tr>
                    <tr><th width="30%">City</th><td width="2%">:</td><td>{item.city}</td></tr>
                    <tr><th width="30%">Price</th><td width="2%">:</td><td>{item.price}</td></tr>
                    <tr><th width="30%">Total Slots</th><td width="2%">:</td><td>{item.totalslots}</td></tr>
                    <tr><th width="30%">Available Slots</th><td width="2%">:</td><td>{item.availableslots}</td></tr>
                    {/* <tr><th width="30%">Owner Id</th><td width="2%">:</td><td>{item.owner._id}</td></tr> */}
                    {/* <tr><th width="30%">Owner Name</th><td width="2%">:</td><td>{item.owner.name}</td></tr>
                    <tr><th width="30%">Phone Number</th><td width="2%">:</td><td>{item.owner.number}</td></tr>
                    <tr><th width="30%">Email</th><td width="2%">:</td><td>{item.owner.email}</td></tr> */}
                    </tbody>
                 </table>
            </CardBody>
            </Card>
            </>
           )
        })}
        </div>
        
        )
          
    }
        