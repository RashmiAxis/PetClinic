import axios from "axios";
import React,{Fragment, useEffect,useState} from "react";
import { Button, Container, Form,FormGroup,Input ,Label} from "reactstrap";
import base_url from "../api/bootapi";
import { ToastContainer, toast } from 'react-toastify';


const AddPet=()=>{
  useEffect(()=>{
    document.title="Add Pet || Welcome to Pet Clinic"
},[]);
const[pet,setpet]=useState([]);

//form handler function
const handleForm=(e)=>{
  postpetDatatoserver(pet);
  e.preventDefault();
  console.log(pet);
};

//creating function to post data on server
const postpetDatatoserver=(data)=>{
  axios.post(`http://newpetclinicservices-env.eba-vkgx5txv.us-east-2.elasticbeanstalk.com/add/addPets`,data).then(//error: 404 http://localhost:3000/add-Owner
    //http://localhost:3000/owner
    (response)=>{
      console.log(response);
      console.log("success");
            toast.success("Sucessfully Added");
    },
    (error)=>{
      console.log(error);
      console.log("error");
            toast.error("Error");

    }
  );
};

    return(
        
           <Fragment>
            <h1 className="text-center my-3">Fill Pet details</h1>
           <Form onSubmit={handleForm}>
           <div class="jumbotron" className="text-center" style={{backgroundColor:"lightgray"}}>
            <div class="form-group">
    <label for="exampleInputpetName">Pet Name</label>
    <Input type="text" name="petName" class="form-control" id="exampleInputpetName" onChange={(e)=>{setpet({...pet,petName:e.target.value});}}aria-describedby="nameHelp" placeholder="Enter Pet Name"/></div>
    <FormGroup>
    <div class="jumbotron" className="text-center" style={{backgroundColor:"lightgray"}}>
    <Label for="examplebreed">
      Pet Breed
    </Label>
    <Input
    id="exampleInputbreed"
      type="text" name="breed"
      onChange={(e)=>{setpet({...pet,breed:e.target.value});}}
     
      placeholder="Enter Pet Breed"
     
    /></div>
  </FormGroup>
  </div>
  <div class="form-group">
  <div class="jumbotron" className="text-center" style={{backgroundColor:"lightgray"}}>
    <label for="exampleInputbirthDate">Pet Birth Date</label>
    <Input type="text" name="birthDate" class="form-control"  id="exampleInputbirthDate" onChange={(e)=>{setpet({...pet,birthDate:e.target.value});}}aria-describedby="emailHelp" placeholder="Pet Breed"/>
    
  </div></div><br></br>
  <Container className="text-center">
    <Button type="submit" color="success">Add Pet</Button>
    <Button color="warning ml-4" style={{marginLeft:"15px"}}>Reset</Button>
</Container>

</Form>
</Fragment>

        
    )
}
export default AddPet;