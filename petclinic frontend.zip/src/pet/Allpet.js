import React, { useState,useEffect} from "react";
import Pet from "./pet";
import axios from "axios";
import base_url from "../api/bootapi";
import { ToastContainer, toast } from 'react-toastify';
import { Card,CardBody,CardTitle,CardSutitle,CardText,CardFooter,Button,Container, CardSubtitle } from "reactstrap";


export default function AllPet(){
     useEffect(()=>{
       document.title="All Pets || Welcome to pet clinic";
       addpetdatatoserver();
   },[]);

     const[pet,setpet]=useState([]);

     //function to call server
     async function addpetdatatoserver (){
    await axios.get(`http://newpetclinicservices-env.eba-vkgx5txv.us-east-2.elasticbeanstalk.com/add/getAllPet`).then(
        (response)=>{
             //for success
           console.log(response.data);
            toast.success("Sucessfully Uploaded");
            setpet(()=>response.data);
          
         
           
        },
         (error)=>{
            //for error
             console.log(error);
            toast.error("Error");
        }
    )
 }
 console.log(pet);
//calling loading booking function
//npx json-server --watch Addowner.json

    

    return(
        <div> 
           {pet.map(item =>{  
        return(
        <div>
            <Card className="text-center">
            
            <CardBody>
            
                <CardText className="font-weight-bold">{item.petName}</CardText>
                <CardText>{item.breed}</CardText>
                <CardText>{item.birthDate}</CardText>
                
                <Container className="text-center">
                </Container>
            </CardBody>
          </Card>
        </div>
    )
}  ) }
</div>) }

