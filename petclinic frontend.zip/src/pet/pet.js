import React ,{useState,useEffect}  from "react";
import { Card,CardBody,CardTitle,CardSutitle,CardText,CardFooter,Button,Container, CardSubtitle } from "reactstrap";
import { ToastContainer, toast } from 'react-toastify';
import axios from "axios";
import base_url from "../api/bootapi";

export default function pet(){
    const[pet,setPet]= useState([]);

     useEffect(()=>{
         document.title="All Pet || Welcome to pet clinic";

         async function viewPetfromserver(){
         await axios.get(`http://newpetclinicservices-env.eba-vkgx5txv.us-east-2.elasticbeanstalk.com/add/getAllPet`).then(
             (response)=>{
                //for success
                 console.log(response.data);
                 toast.success("Sucessfully uploaded");
                 setPet(()=>response.data);
                 
             },
             (error)=>{
               //for error
                 console.log(error);
                 toast.error("Error");
             }
         )
         }
         viewPetfromserver();
         
     },[]);

     console.log(pet);

   //calling loading booking function
  //npx json-server --watch Addowner.json

    return(
        <div>
            <h1 className="text-center">Pet Details</h1>
            {pet.map(item=>{
                 return(
                    <div>
                        <Card className="text-center">                        
                            <CardBody>                        
                            <table className="table table-bordered text-center table-striped">
                    <tbody>
                    <tr><th width="30%">Pet Name</th><td className="text-center" width="2%">:</td><td>{item.petName}</td></tr>
                    <tr><th width="30%">Breed</th><td width="2%">:</td><td>{item.breed}</td></tr>
                    <tr><th width="30%">Birth Date</th><td width="2%">:</td><td>{item.birthDate}</td></tr>
                    
                    </tbody>
                 </table>
                            </CardBody>
                        </Card>
                    </div>
                )
            })}
        </div>
    )
           
                
            
      
    
}
        
        