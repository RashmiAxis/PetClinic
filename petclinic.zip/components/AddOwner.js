import axios from "axios";
import React,{Fragment, useEffect,useState} from "react";
import { Button, Container, Form,FormGroup,Input ,Label} from "reactstrap";
import base_url from "../api/bootapi";
import { ToastContainer, toast } from 'react-toastify';


const AddOwner=()=>{
  useEffect(()=>{
    document.title="Add Owners || Welcome to Pet Clinic"
},[]);
const[owner,setOwner]=useState({})

//form handler function
const handleForm=(e)=>{
  postDatatoserver(owner);
  e.preventDefault();
  console.log(owner.id);
};

//creating function to post data on server
const postDatatoserver=(data)=>{
  axios.post(`${base_url}/owner`,data).then(//error: 404 http://localhost:3000/add-Owner
    //http://localhost:3000/owner
    (response)=>{
      console.log(response);
      console.log("success");
            toast.success("Sucessfully Added");
    },
    (error)=>{
      console.log(error);
      console.log("error");
            toast.error("Error");

    }
  );
};

    return(
        
           <Fragment>
            <h1 className="text-center my-3">Fill Owner details</h1>
           <Form onSubmit={handleForm}>
  <div class="form-group">
    <label for="exampleInputid">Adhaar Card</label>
    <Input type="text" name="Adhaarr_Card" class="form-control" id="exampleInputid" onChange={(e)=>{setOwner({...owner,id:e.target.value});}} aria-describedby="idHelp" placeholder="Enter adhaar card number"/>
  </div>
            <div class="form-group">
    <label for="exampleInputname">Name</label>
    <Input type="text" name="name" class="form-control" id="exampleInputname" onChange={(e)=>{setOwner({...owner,name:e.target.value});}}aria-describedby="nameHelp" placeholder="Enter your name"/>
    <FormGroup>
    <Label for="exampleNumber">
      Mobile Number
    </Label>
    <Input
      type="text" name="number"
      onChange={(e)=>{setOwner({...owner,number:e.target.value});}}
      name="Mobile Number"
      placeholder="Enter your mobile number"
      type="Mobile Number"
    />
  </FormGroup>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <Input type="email" name="email" class="form-control" email="exampleInputEmail1" onChange={(e)=>{setOwner({...owner,email:e.target.value});}}aria-describedby="emailHelp" placeholder="Enter email"/>
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <Input type="password" name="password" class="form-control" password="exampleInputPassword1" onChange={(e)=>{setOwner({...owner,password:e.target.value});}} placeholder="Password"/>
    <small id="passwordHelp" class="form-text text-muted">Your Password is not visible to others.</small>
  </div>
  <Container className="text-center">
    <Button type="submit" color="success">Add Owner</Button>
    <Button color="warning ml-4">Reset</Button>
</Container>

</Form>
</Fragment>

        
    )
}
export default AddOwner;