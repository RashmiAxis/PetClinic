import React, { useState,useEffect} from "react";
import AddOwner from "./AddOwner";
import Owner from "./Owner";



const AllBookings=()=>{
    useEffect(()=>{
        document.title="All Bookings || Welcome to pet clinic";
    },[]);
    const[owner,setOwner]=useState([{id:65,name:"rashmi"}]);

    /*//function to call server
   const addOwnertoserver=()=>{
    axios.get(`${base_url}/owner`).then(
        (response)=>{
            //for success
            console.log(response.data);
            toast.success("Sucessfully Added");
            setOwner(response.data);
        },
        (error)=>{
            //for error
            console.log(error);
            toast.error("Error");
        }
    )
}

//calling loading booking function
//npx json-server --watch Addowner.json
useEffect(()=>{
addOwnertoserver();},[])*/

    

    return(
        <div>
            <h1 className="text-center">All Booking</h1>
            
            {owner.length>0
            ? owner.map((item)=><Owner  owner={item}/>)
           // ? owner.map((item)=><Owner key={item.id} owner={item}/>)//use this syntax when connect to api
            :"No Booking"}
           
        </div>
    )
}
export default AllBookings;
