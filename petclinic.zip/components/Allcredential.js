import React, { useState,useEffect} from "react";

import user from "./credential";



const AllCredential=()=>{
    useEffect(()=>{
        document.title="All Credential || Welcome to pet clinic";
    },[]);
    const[user,setUser]=useState([]);

    //function to call server
   const postRegistertoserver=()=>{
    axios.post(`${base_url}/register`).then(
        (response)=>{
            //for success
            console.log(response.data);
            toast.success("Sucessfully Registered!!");
            setUser(response.data);
        },
        (error)=>{
            //for error
            console.log(error);
            toast.error("Error");
        }
    )


    useEffect(()=>{
        postRegistertoserver();},[])
    
}


    return(
        <div>
            
            
            {user.length>0
            ? user.map((item)=><Credential key={item.id} user={item}/>)
           // ? owner.map((item)=><Owner key={item.id} owner={item}/>)//use this syntax when connect to api
            :"No Details"}
           
        
         
        </div>
    )
}
export default AllCredential;

