import React from "react";
import { Card, CardBody } from "reactstrap";

function Header({name}){
    return(
        
        <div>
            <Card className="my-1"style={{backgroundColor:"yellow"}} >
                <CardBody>
                    <h1 className=" text-center my-2 ">Welcome to Pet Clinic Application</h1>
                </CardBody>
            </Card>
        </div>
    )

}
export default Header;