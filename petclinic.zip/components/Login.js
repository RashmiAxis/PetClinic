import React,{Fragment, useEffect,useState} from "react";
import { Link } from "react-router-dom";
import { Button, Container, Form,FormGroup,Input ,Label,ListGroup, ListGroupItem} from "reactstrap";
import axios from "axios";
import base_url from "../api/bootapi";
import { ToastContainer, toast } from 'react-toastify';
import user from "./credential";

const Login=()=>{
    useEffect(()=>{
        document.title="Login || Welcome to pet clinic";
    },[]);
    const[signin,setSignIn]=useState([]);
    //form handler function
const handleForm=(e)=>{
    postLogindetailstoserver(signin);
    e.preventDefault();
    console.log(signin);
  };
   const postLogindetailstoserver=(data)=>{
    axios.post(`${base_url}/signin`,data).then(
      
        (response)=>{
          console.log(response);
          console.log("success");
                toast.success("Sucessfully Login!!");
        },
        (error)=>{
          console.log(error);
          console.log("error");
                toast.error("Error");
   
        }
      );
    };
    //calling loading login function
    //npx json-server --watch Addowner.json
    
    return(
     
        <Fragment>
        <h1 className="text-center my-3">Login</h1><hr/>
       <Form onSubmit={handleForm}>

<div class="jumbotron" className="text-center" style={{backgroundColor:"lightgray"}}>
        <div class="form-group">
<label for="exampleInputname">Name</label>
<Input type="text" name="name" class="form-control" name="exampleInputname" onChange={(e)=>{setSignIn({...signin,name:e.target.value});}} aria-describedby="nameHelp" placeholder="Enter your name"/>
</div>
</div>
<div class="jumbotron" className="text-center" style={{backgroundColor:"lightgray"}}>
<div class="form-group">
<label for="exampleInputPassword1">Password</label>
<Input type="password" name="password" onChange={(e)=>{setSignIn({...signin,password:e.target.value});}}class="form-control" password="exampleInputPassword1"  placeholder="Password"/>
</div>
</div><div><hr/>
<Container>
<Button type="submit"  color="success" outline type="regiter">Login</Button>
<Link tag="a" to="/" className="absolute" action><Button  color="danger" outline>Cancel</Button></Link>

</Container>
</div>


</Form>

  
</Fragment>

    
)
       
    }
export default Login;