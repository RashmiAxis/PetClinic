import React from "react";
import { ListGroup, ListGroupItem } from "reactstrap";

const Menu=()=>{
    return(
        <ListGroup className="menu">
  <ListGroupItem tag="a" href="/" action>Home</ListGroupItem>
  <ListGroupItem tag="a" href="/aboutUs" action>About us</ListGroupItem>
  <ListGroupItem tag="a" href="/add-Owner" action>Add Owner</ListGroupItem>
  <ListGroupItem tag="a" href="/view-AllBookings" action>View Bookings</ListGroupItem>
  <ListGroupItem tag="a" href="#!" action>Visits</ListGroupItem>
  <ListGroupItem tag="a" href="#!" action>Booking</ListGroupItem>
  <ListGroupItem tag="a" href="/ContactUs" action>Contact us</ListGroupItem>
</ListGroup>
    )
}
export default Menu;