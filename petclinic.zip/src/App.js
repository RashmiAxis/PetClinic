import Header from './components/Header';
import './App.css';
import Home from './components/Home';
import 'react-accessible-accordion/dist/fancy-example.css';
import { ToastContainer, toast } from 'react-toastify';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Navbar ,Container,Nav,NavDropdown,FormControl,NavLink} from 'react-bootstrap';
import AddOwner from './components/AddOwner';
import { Col, Row } from 'reactstrap';
import Menu from './components/Menu';
import { BrowserRouter as Router,Route,Link,Switch} from "react-router-dom";
import About from './components/About';
import Contact from './components/Contact';
import AllBookings from './components/AllOwners';
import Login from './components/Login';
import Register from './components/Register';

function App() {
 

  const btnHandle=()=>
  {toast.success("Sucess")}

  return ( 
   <>
   
   <div>
   
     <Router>
     <ToastContainer/>
     <Container>
  
       <Header/>
       <Row>
         <Col md={4}>
           <Menu/>
         </Col>
         <Col md={8}>
           <Route path="/" component={Home} exact/>
           <Route path="/aboutUs" component={About} exact/>
           <Route path="/add-Owner" component={AddOwner} exact/>
           <Route path="/view-AllBookings" component={AllBookings} exact/>
           <Route path="/ContactUs" component={Contact} exact/>
           <Route path="/home-login" component={Login} exact/>
           <Route path="/home-register" component={Register} exact/>
         </Col>
       </Row>
     </Container>
     </Router>
  </div>
   </>
  );
}

export default App;
