import React,{useEffect} from "react";
import { Button, Container, Form,FormGroup,Input } from "reactstrap";

const AddOwner=()=>{
  useEffect(()=>{
    document.title="Add Owners || Welcome to Pet Clinic"
},[])
    return(
        
            <Form>
            <h1 className="text-center my-3">Fill Owner details</h1>
           
  <div class="form-group">
    <label for="exampleInputid">Adhaar Card</label>
    <Input type="id" class="form-control" id="exampleInputid" aria-describedby="idHelp" placeholder="Enter adhaar card number"/>
  </div>
            <div class="form-group">
    <label for="exampleInputname">Name</label>
    <Input type="name" class="form-control" id="exampleInputname1" aria-describedby="nameHelp" placeholder="Enter your name"/>

  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <Input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email"/>
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <Input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password"/>
    <small id="passwordHelp" class="form-text text-muted">Your Password is not visible to others.</small>
  </div>
  <Container className="text-center">
    <Button color="success">Add Owner</Button>
    <Button color="warning ml-4">Reset</Button>
</Container>

</Form>

        
    )
}
export default AddOwner;