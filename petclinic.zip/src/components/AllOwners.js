import React, { useState,useEffect} from "react";
import { Accordion } from "reactstrap";
import Owner from "./Owner";


const AllOwners=()=>{
    useEffect(()=>{
        document.title="All Bookings || Welcome to pet clinic"
    },[])

    //function to call server
   /*const getAllBookingFromServer=()=>{
        axios.get(`${base_url}/getAllBooking`).then(
            (response)=>{
                //for success
                console.log(response.data);
            },
            (error)=>{
                //for error
                console.log(error);
            }
        )
    }

    //calling loading bookinf function
    useEffect(()=>{
     getAllBookingFromServer();},[])*/

    const[owner,setOwner]=useState([
        {name:"rashmi",id:"456"},
        {name:"pankaj",id:"987"},
        {name:"rohit",id:"677"}
    ])

    return(
        <div>
            <h1 className="text-center">All Booking</h1>
    
            {owner.length>0
            ?owner.map((item)=><Owner owner={item}/>):"No Booking"}
        </div>
    )
}
export default AllOwners;
