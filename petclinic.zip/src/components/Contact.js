import React,{useEffect} from "react";

const Contact=()=>{
    useEffect(()=>{
        document.title="Contact Us"
    },[])
    return(
        <div className="jumbotron" style={{backgroundColor:"light green"}}>
           <h3>Phone number</h3>
           <p>+91-7578656467</p>
           <p>+91-4466490094</p>
           <p>+91-4466490094</p>
           <h3>Email Us</h3>
           <p>petclinic21@.gmail.com</p>
        </div>
    )
}
export default Contact;