import React,{useEffect} from "react";
import {Button, Container, Jumbotron} from 'reactstrap';

const Home=()=>{
    useEffect(()=>{
        document.title="Home || Welcome to Pet Clinic"
    },[])
    return(
        <div class="jumbotron" style={{backgroundColor:"lightgray"}}>
  <h1 style={{backgroundColor:"lemon"}}>Welcome to Pet Clinic Application</h1>
  <p >PetClinic demonstrates the use of a Spring Boot with Spring MVC and Spring Data. The PetClinic has an old</p>
  <hr/>
 <Container>
     <Button color="primary" outline>Start</Button>
 </Container>
</div>
    )
}
export default Home;
