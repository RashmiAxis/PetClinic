import React,{useEffect} from "react";
import { Card,CardBody,CardTitle,CardSutitle,CardText,CardFooter,Button,Container, CardSubtitle } from "reactstrap";

const Owner=({owner})=>{
    useEffect(()=>{
        document.title="Owners"
    },[])
    return(
        <Card className="text-center">
          <CardBody>
              <CardSubtitle className="font-weight-bold">{owner.name}</CardSubtitle>
                  <CardText>{owner.id}</CardText>
                  <Container >
                      <Button color="warning ml-3">Add</Button>
                      <Button color="danger ml-3">Delete</Button>
                  </Container>
          </CardBody>
        </Card>
    )
}
export default Owner;